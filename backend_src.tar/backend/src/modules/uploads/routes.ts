import { FastifyInstance } from 'fastify'
import { authenticate } from '../../middleware/auth.js'
import { uploadNoteImage, deleteNoteImage, uploadChatImage } from './service.js'
import { AppError } from '../../utils/errors.js'
import { env } from '../../config/env.js'

export async function uploadsRoutes(app: FastifyInstance) {
  // POST /uploads/chat-image?compressed=true|false
  app.post('/chat-image', { preHandler: [authenticate] }, async (request, reply) => {
    const { compressed } = request.query as { compressed?: string }

    const data = await request.file({
      limits: { fileSize: env.MAX_UPLOAD_SIZE },
    })

    if (!data) {
      return reply.status(400).send({ error: 'Файл не загружен', code: 'VALIDATION_ERROR' })
    }

    try {
      const image = await uploadChatImage(
        app,
        request.user.userId,
        {
          filename: data.filename,
          mimetype: data.mimetype,
          file: data.file,
        },
        { compressed: compressed !== 'false' },
      )
      return reply.status(201).send(image)
    } catch (err) {
      if (err instanceof AppError) return reply.status(err.statusCode).send({ error: err.message, code: err.code })
      throw err
    }
  })

  // DELETE /uploads/note-image/:imageId
  app.delete<{ Params: { imageId: string } }>(
    '/note-image/:imageId',
    { preHandler: [authenticate] },
    async (request, reply) => {
      try {
        await deleteNoteImage(app, request.user.userId, request.params.imageId)
        return reply.status(204).send()
      } catch (err) {
        if (err instanceof AppError) return reply.status(err.statusCode).send({ error: err.message, code: err.code })
        throw err
      }
    },
  )

  // POST /uploads/note-image?noteId=xxx
  app.post('/note-image', { preHandler: [authenticate] }, async (request, reply) => {
    const { noteId } = request.query as { noteId?: string }

    if (!noteId) {
      return reply.status(400).send({ error: 'noteId обязателен', code: 'VALIDATION_ERROR' })
    }

    const data = await request.file({
      limits: { fileSize: env.MAX_UPLOAD_SIZE },
    })

    if (!data) {
      return reply.status(400).send({ error: 'Файл не загружен', code: 'VALIDATION_ERROR' })
    }

    try {
      const image = await uploadNoteImage(app, request.user.userId, noteId, {
        filename: data.filename,
        mimetype: data.mimetype,
        file: data.file,
      })
      return reply.status(201).send(image)
    } catch (err) {
      if (err instanceof AppError) return reply.status(err.statusCode).send({ error: err.message, code: err.code })
      throw err
    }
  })
}
