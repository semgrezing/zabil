import { FastifyInstance } from 'fastify'
import { pipeline } from 'stream/promises'
import sharp from 'sharp'
import { v4 as uuidv4 } from 'uuid'
import path from 'path'
import fs from 'fs'
import { errors } from '../../utils/errors.js'
import { env } from '../../config/env.js'
import { requireGroupMember } from '../../middleware/auth.js'

const ALLOWED_MIME_TYPES = new Set(['image/jpeg', 'image/jpg', 'image/png', 'image/webp'])
const ALLOWED_EXTENSIONS = new Set(['.jpg', '.jpeg', '.png', '.webp'])
// Magic bytes for image validation
const MAGIC_BYTES: Record<string, number[]> = {
  'image/jpeg': [0xff, 0xd8, 0xff],
  'image/png': [0x89, 0x50, 0x4e, 0x47],
  'image/webp': [0x52, 0x49, 0x46, 0x46],
}

function ensureDir(dir: string) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true })
  }
}

function checkMagicBytes(buffer: Buffer, mimeType: string): boolean {
  const magic = MAGIC_BYTES[mimeType]
  if (!magic) return false
  return magic.every((byte, i) => buffer[i] === byte)
}

export async function uploadNoteImage(
  app: FastifyInstance,
  userId: string,
  noteId: string,
  file: {
    filename: string
    mimetype: string
    file: NodeJS.ReadableStream
  }
) {
  // Validate note exists and user has access
  const note = await app.prisma.note.findFirst({
    where: { id: noteId, deletedAt: null },
  })
  if (!note) throw errors.notFound('Заметка')

  const isMember = await requireGroupMember(app, userId, note.groupId)
  if (!isMember) throw errors.forbidden()

  // Validate mime type
  if (!ALLOWED_MIME_TYPES.has(file.mimetype)) {
    throw errors.badRequest('Допустимы только изображения: jpg, png, webp')
  }

  const ext = path.extname(file.filename).toLowerCase()
  if (!ALLOWED_EXTENSIONS.has(ext)) {
    throw errors.badRequest('Недопустимое расширение файла')
  }

  // Read file into buffer with size check
  const chunks: Buffer[] = []
  let totalSize = 0

  for await (const chunk of file.file) {
    totalSize += chunk.length
    if (totalSize > env.MAX_UPLOAD_SIZE) {
      throw errors.badRequest(`Файл превышает максимальный размер ${env.MAX_UPLOAD_SIZE / 1024 / 1024}MB`)
    }
    chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk))
  }

  const buffer = Buffer.concat(chunks)

  // Validate magic bytes
  if (!checkMagicBytes(buffer, file.mimetype)) {
    throw errors.badRequest('Файл не является изображением')
  }

  // Compress and convert using sharp
  const outputFilename = `${uuidv4()}.webp`
  const uploadDir = path.join(env.UPLOADS_PATH, 'notes')
  ensureDir(uploadDir)
  const outputPath = path.join(uploadDir, outputFilename)

  await sharp(buffer)
    .resize({ width: 2048, height: 2048, fit: 'inside', withoutEnlargement: true })
    .webp({ quality: 85 })
    .toFile(outputPath)

  const stats = fs.statSync(outputPath)

  // Save to DB
  const image = await app.prisma.noteImage.create({
    data: {
      noteId,
      filename: outputFilename,
      originalName: file.filename,
      mimeType: 'image/webp',
      fileSize: stats.size,
      path: outputPath,
    },
  })

  return image
}

export async function deleteNoteImage(
  app: FastifyInstance,
  userId: string,
  imageId: string,
) {
  const image = await app.prisma.noteImage.findUnique({
    where: { id: imageId },
    include: { note: true },
  })
  if (!image) throw errors.notFound('Изображение')
  if (image.note.deletedAt) throw errors.notFound('Изображение')

  const isMember = await requireGroupMember(app, userId, image.note.groupId)
  if (!isMember) throw errors.forbidden()

  // Удаляем файл с диска (если файл не найден — игнорируем, БД важнее)
  try {
    if (fs.existsSync(image.path)) {
      fs.unlinkSync(image.path)
    }
  } catch (_) {
    // best-effort cleanup; продолжаем удалять запись из БД
  }

  await app.prisma.noteImage.delete({ where: { id: imageId } })
}

export async function uploadChatImage(
  _app: FastifyInstance,
  _userId: string,
  file: {
    filename: string
    mimetype: string
    file: NodeJS.ReadableStream
  },
  opts: { compressed: boolean },
) {
  if (!ALLOWED_MIME_TYPES.has(file.mimetype)) {
    throw errors.badRequest('Допустимы только изображения: jpg, png, webp')
  }

  const ext = path.extname(file.filename).toLowerCase()
  if (!ALLOWED_EXTENSIONS.has(ext)) {
    throw errors.badRequest('Недопустимое расширение файла')
  }

  const chunks: Buffer[] = []
  let totalSize = 0

  for await (const chunk of file.file) {
    totalSize += chunk.length
    if (totalSize > env.MAX_UPLOAD_SIZE) {
      throw errors.badRequest(`Файл превышает максимальный размер ${env.MAX_UPLOAD_SIZE / 1024 / 1024}MB`)
    }
    chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk))
  }

  const buffer = Buffer.concat(chunks)

  if (!checkMagicBytes(buffer, file.mimetype)) {
    throw errors.badRequest('Файл не является изображением')
  }

  const uploadDir = path.join(env.UPLOADS_PATH, 'chat')
  ensureDir(uploadDir)

  let outputFilename = `${uuidv4()}.webp`
  let outputPath = path.join(uploadDir, outputFilename)
  let outputMime = 'image/webp'

  if (opts.compressed) {
    await sharp(buffer)
      .resize({ width: 2048, height: 2048, fit: 'inside', withoutEnlargement: true })
      .webp({ quality: 82 })
      .toFile(outputPath)
  } else {
    outputFilename = `${uuidv4()}${ext}`
    outputPath = path.join(uploadDir, outputFilename)
    fs.writeFileSync(outputPath, buffer)
    outputMime = file.mimetype
  }

  const stats = fs.statSync(outputPath)

  return {
    url: `/uploads/chat/${outputFilename}`,
    mimeType: outputMime,
    fileSize: stats.size,
    originalName: file.filename,
    compressed: opts.compressed,
  }
}
